import SwiftUI

class DataManager: ObservableObject {
    @Published var entries: [GenderEntry] = []
    @Published var profile: UserProfile = UserProfile(
        name: "User",
        pronouns: "They/Them",
        sexuality: "Pansexual",
        birthday: Date(),
        streak: 0
    )
    
    let entriesKey = "genderEntries"
    let profileKey = "userProfile"
    
    init() {
        loadEntries()
        loadProfile()
    }
    
    func saveEntries() {
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: entriesKey)
        }
    }
    
    func loadEntries() {
        if let data = UserDefaults.standard.data(forKey: entriesKey),
           let decoded = try? JSONDecoder().decode([GenderEntry].self, from: data) {
            entries = decoded
        }
    }
    
    func saveProfile() {
        if let data = try? JSONEncoder().encode(profile) {
            UserDefaults.standard.set(data, forKey: profileKey)
        }
    }
    
    func loadProfile() {
        if let data = UserDefaults.standard.data(forKey: profileKey),
           let decoded = try? JSONDecoder().decode(UserProfile.self, from: data) {
            profile = decoded
        }
    }
}

