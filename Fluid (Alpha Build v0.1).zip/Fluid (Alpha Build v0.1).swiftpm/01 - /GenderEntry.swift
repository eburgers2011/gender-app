import SwiftUI

struct GenderEntry: Identifiable, Codable, Equatable {
    var id = UUID()
    var date: Date
    var gender: String
    var malePercent: Double
    var femalePercent: Double
    var nonBinaryPercent: Double
    var notes: String
    
    var genderColor: Color {
        switch gender {
        case "Agender": return .gray
        case "Male": return .blue
        case "Female": return .red
        case "Bigender": return .purple
        case "Non-Binary": return .yellow
        case "Demi-Boy": return Color("LightBlue") // define custom color in Assets
        case "Demi-Girl": return Color("LightPink")
        case "Androgyne": return .white
        case "Fluid": return Color("LightPurple")
        default: return .secondary
        }
    }
    
    var genderImageName: String {
        switch gender {
        case "Agender": return "agender_placeholder"
        case "Male": return "male_placeholder"
        case "Female": return "female_placeholder"
        case "Bigender": return "bigender_placeholder"
        case "Non-Binary": return "enby_placeholder"
        case "Demi-Boy": return "demiboy_placeholder"
        case "Demi-Girl": return "demigirl_placeholder"
        case "Androgyne": return "androgyne_placeholder"
        case "Fluid": return "fluid_placeholder"
        default: return "default_placeholder"
        }
    }

}
