import SwiftUI

struct UserProfile: Codable {
    var name: String
    var pronouns: String
    var sexuality: String
    var birthday: Date
    var streak: Int
}
