import SwiftUI

@main
struct GenderTrackerApp: App {
    @StateObject var data = DataManager()
    
    var body: some Scene {
        WindowGroup {
            TabView {
                HomeView(data: data)
                    .tabItem { Label("Home", systemImage: "house") }
                
                CalendarScreen(data: data)
                    .tabItem { Label("Calendar", systemImage: "calendar") }
                
                ProfileView(data: data)
                    .tabItem { Label("Profile", systemImage: "person.crop.circle") }
            }
        }
    }
}
