Welcome to the Alpha (v0.2) version of Fluid!

Im probably gonna write something here but im trying to fuckimg troubleshoot rn hopefully i dont forget. later dudes
