This file is to document changes made. Each change should be listed under a date and build version. Feel free to view, but do not edit unless you have made a change. Do NOT just remove things from the log. Instead, document that it was removed. Newest changes/builds should be listed at the top.




v0.2 (Alpha Build) 11/11/25 - Present

    11/11/25
    •    Working on a Discover Tab.
    •    Working on adding icons for genders.
    
    
    
    
    
v0.1 (Initial Build) 11/10/25 - 11/11/25

    11/11/25
    •    Core app structure created (Home, Add Gender, Calendar).
    •    Added gender selection with colors, auto-set sliders, and notes.
    •    Functional calendar with date-based entry viewing.
    •    Entries save locally and persist between sessions.
