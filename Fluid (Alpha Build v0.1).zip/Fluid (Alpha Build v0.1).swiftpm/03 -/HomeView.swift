import SwiftUI

struct HomeView: View {
    @ObservedObject var data: DataManager
    @State private var showAdd = false
    
    var body: some View {
        VStack {
            Text("Welcome back, \(data.profile.name)!")
                .font(.largeTitle)
                .padding(.top)
            
            // Recent entries
            if !data.entries.isEmpty {
                VStack(alignment: .leading) {
                    Text("Recent Entries:")
                        .font(.headline)
                    ForEach(data.entries.sorted(by: { $0.date > $1.date }).prefix(3)) { entry in
                        HStack {
                            Circle()
                                .fill(entry.genderColor)
                                .frame(width: 12, height: 12)
                            Text("\(entry.gender) • \(entry.date.formatted(date: .abbreviated, time: .omitted))")
                        }
                    }
                }
                .padding()
            }
            
            // Add New Gender button
            Button(action: { showAdd = true }) {
                Text("Add New Gender")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.accentColor)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .padding(.horizontal)
            }
            .sheet(isPresented: $showAdd) {
                AddGenderView(data: data)
            }
            
            Spacer()
        }
        .padding()
    }
}

