import SwiftUI

struct ProfileView: View {
    @ObservedObject var data: DataManager
    @State private var showEdit = false
    
    var averageGender: String {
        let counts = Dictionary(grouping: data.entries, by: { $0.gender }).mapValues { $0.count }
        return counts.max(by: { $0.value < $1.value })?.key ?? "None"
    }
    
    var body: some View {
        VStack(spacing: 12) {
            Text(data.profile.name)
                .font(.largeTitle)
            Text("\(data.profile.pronouns) • \(data.profile.sexuality)")
                .foregroundColor(.secondary)
            
            Text("🎂 \(formattedDate(data.profile.birthday))")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Divider()
            
            Text("🔥 Streak: \(data.profile.streak) days")
                .font(.headline)
            
            Text("Most Frequent Gender: \(averageGender)")
                .font(.headline)
            
            Spacer()
            
            Button("Edit Profile") {
                showEdit = true
            }
            .buttonStyle(.borderedProminent)
            .sheet(isPresented: $showEdit) {
                EditProfileView(data: data)
            }
        }
        .padding()
    }
    
    func formattedDate(_ date: Date) -> String {
        let fmt = DateFormatter()
        fmt.dateStyle = .medium
        return fmt.string(from: date)
    }
}

struct EditProfileView: View {
    @ObservedObject var data: DataManager
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        Form {
            TextField("Name", text: $data.profile.name)
            TextField("Pronouns", text: $data.profile.pronouns)
            TextField("Sexuality", text: $data.profile.sexuality)
            DatePicker("Birthday", selection: $data.profile.birthday, displayedComponents: .date)
        }
        .toolbar {
            Button("Save") {
                data.saveProfile()
                dismiss()
            }
        }
    }
}
