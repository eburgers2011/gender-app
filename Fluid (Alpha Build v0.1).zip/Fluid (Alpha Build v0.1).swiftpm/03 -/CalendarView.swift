import SwiftUI

struct CalendarView: View {
    @Binding var entries: [GenderEntry]
    @Binding var selectedDate: Date?
    
    let columns = Array(repeating: GridItem(.flexible()), count: 7)
    
    var body: some View {
        VStack {
            Text("Calendar")
                .font(.title)
                .padding(.top)
            
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(generateDaysInMonth(), id: \.self) { date in
                    CalendarDayView(
                        date: date,
                        entry: entries.first(where: { Calendar.current.isDate($0.date, inSameDayAs: date) }),
                        isSelected: Calendar.current.isDate(selectedDate ?? Date(), inSameDayAs: date)
                    )
                    .onTapGesture {
                        selectedDate = date
                    }
                }
            }
            .padding()
        }
    }
    
    private func generateDaysInMonth() -> [Date] {
        let calendar = Calendar.current
        let range = calendar.range(of: .day, in: .month, for: Date()) ?? 1..<31
        let startOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: Date()))!
        return range.compactMap { calendar.date(byAdding: .day, value: $0 - 1, to: startOfMonth) }
    }
}

struct CalendarDayView: View {
    var date: Date
    var entry: GenderEntry?
    var isSelected: Bool
    
    var body: some View {
        VStack {
            Text("\(Calendar.current.component(.day, from: date))")
                .font(.headline)
                .foregroundColor(.primary)
            
            if let entry = entry {
                Circle()
                    .fill(entry.genderColor)
                    .frame(width: 20, height: 20)
            } else {
                Circle()
                    .stroke(Color.secondary, lineWidth: 1)
                    .frame(width: 20, height: 20)
            }
        }
        .padding(4)
        .background(isSelected ? Color.accentColor.opacity(0.2) : Color.clear)
        .cornerRadius(8)
    }
}


