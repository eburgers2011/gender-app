import SwiftUI

struct AddGenderView: View {
    @ObservedObject var data: DataManager
    @Environment(\.dismiss) private var dismiss
    
    // State
    @State private var selectedGender: String = ""
    @State private var malePercent: Double = 0
    @State private var femalePercent: Double = 0
    @State private var nonBinaryPercent: Double = 0
    @State private var notes: String = ""
    
    // Genders list
    let genders = [
        "Agender", "Male", "Female", "Bigender",
        "Non-Binary", "Demi-Boy", "Demi-Girl", "Androgyne", "Fluid"
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    
                    // Title
                    Text("Add New Gender Entry")
                        .font(.largeTitle.bold())
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top)
                    
                    // Gender selection grid
                    Text("Select your gender:")
                        .font(.headline)
                    
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 12)]) {
                        ForEach(genders, id: \.self) { gender in
                            VStack {
                                // Use placeholder image names — you can replace with your asset names later.
                                Image(genderImageName(for: gender))
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .padding(6)
                                    .background(selectedGender == gender ? genderColor(for: gender).opacity(0.28) : Color.clear)
                                    .cornerRadius(12)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(selectedGender == gender ? genderColor(for: gender) : Color.gray.opacity(0.28), lineWidth: 2)
                                    )
                                Text(gender)
                                    .font(.subheadline)
                            }
                            .onTapGesture {
                                selectedGender = gender
                                setSliders(for: gender)
                            }
                        }
                    }
                    
                    // Sliders (labeled and colored)
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Identity Sliders")
                            .font(.headline)
                        
                        HStack {
                            Text("Male").foregroundColor(.blue).frame(width: 72, alignment: .leading)
                            Slider(value: $malePercent, in: 0...100)
                                .accentColor(.blue)
                            Text("\(Int(malePercent))%").frame(width: 48, alignment: .trailing)
                        }
                        
                        HStack {
                            Text("Female").foregroundColor(.red).frame(width: 72, alignment: .leading)
                            Slider(value: $femalePercent, in: 0...100)
                                .accentColor(.red)
                            Text("\(Int(femalePercent))%").frame(width: 48, alignment: .trailing)
                        }
                        
                        HStack {
                            Text("Non-Binary").foregroundColor(.yellow).frame(width: 72, alignment: .leading)
                            Slider(value: $nonBinaryPercent, in: 0...100)
                                .accentColor(.yellow)
                            Text("\(Int(nonBinaryPercent))%").frame(width: 48, alignment: .trailing)
                        }
                    }
                    
                    // Notes section
                    VStack(alignment: .leading) {
                        Text("Notes (optional)")
                            .font(.headline)
                        TextEditor(text: $notes)
                            .frame(height: 100)
                            .padding(8)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.3)))
                    }
                    
                    // Save button
                    Button(action: saveEntry) {
                        Text("Save Entry")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedGender.isEmpty ? Color.gray.opacity(0.4) : Color.accentColor)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .disabled(selectedGender.isEmpty)
                    
                    Spacer()
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    // MARK: - Functions
    
    func saveEntry() {
        // NOTE: use the labeled init order that matches your GenderEntry declaration:
        // GenderEntry(date: Date(), gender: ..., malePercent: ..., femalePercent: ..., nonBinaryPercent: ..., notes: ...)
        let newEntry = GenderEntry(
            date: Date(),
            gender: selectedGender,
            malePercent: malePercent,
            femalePercent: femalePercent,
            nonBinaryPercent: nonBinaryPercent,
            notes: notes
        )
        
        data.entries.append(newEntry)
        data.saveEntries()           // <-- call the method your DataManager actually provides
        dismiss()
    }
    
    func setSliders(for gender: String) {
        switch gender {
        case "Agender":
            malePercent = 0; femalePercent = 0; nonBinaryPercent = 0
        case "Male":
            malePercent = 100; femalePercent = 0; nonBinaryPercent = 0
        case "Female":
            malePercent = 0; femalePercent = 100; nonBinaryPercent = 0
        case "Bigender":
            malePercent = 50; femalePercent = 50; nonBinaryPercent = 0
        case "Non-Binary":
            malePercent = 0; femalePercent = 0; nonBinaryPercent = 100
        case "Demi-Boy":
            malePercent = 70; femalePercent = 0; nonBinaryPercent = 30
        case "Demi-Girl":
            malePercent = 0; femalePercent = 70; nonBinaryPercent = 30
        case "Androgyne":
            malePercent = 50; femalePercent = 50; nonBinaryPercent = 50
        case "Fluid":
            malePercent = 40; femalePercent = 40; nonBinaryPercent = 60
        default:
            malePercent = 0; femalePercent = 0; nonBinaryPercent = 0
        }
    }
    
    func genderColor(for gender: String) -> Color {
        switch gender {
        case "Agender": return .gray
        case "Male": return .blue
        case "Female": return .red
        case "Bigender": return .purple
        case "Non-Binary": return .yellow
        case "Demi-Boy": return Color(red: 0.6, green: 0.85, blue: 1.0) // light blue
        case "Demi-Girl": return Color(red: 1.0, green: 0.75, blue: 0.85) // light pink
        case "Androgyne": return .white
        case "Fluid": return Color(red: 0.8, green: 0.7, blue: 0.95) // light purple
        default: return .secondary
        }
    }
    
    func genderImageName(for gender: String) -> String {
        // placeholder names — replace with real asset names if you add images
        switch gender {
        case "Agender": return "agender_placeholder"
        case "Male": return "male_placeholder"
        case "Female": return "female_placeholder"
        case "Bigender": return "bigender_placeholder"
        case "Non-Binary": return "enby_placeholder"
        case "Demi-Boy": return "demiboy_placeholder"
        case "Demi-Girl": return "demigirl_placeholder"
        case "Androgyne": return "androgyne_placeholder"
        case "Fluid": return "fluid_placeholder"
        default: return "default_placeholder"
        }
    }
}

