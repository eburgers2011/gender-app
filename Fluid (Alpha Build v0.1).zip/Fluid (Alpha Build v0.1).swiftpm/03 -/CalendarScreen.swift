import SwiftUI

struct CalendarScreen: View {
    @ObservedObject var data: DataManager
    @State private var selectedDate: Date? = nil
    @State private var showEntryDetails = false
    @State private var selectedEntry: GenderEntry? = nil
    
    var body: some View {
        VStack {
            CalendarView(entries: $data.entries, selectedDate: $selectedDate)
                .onChange(of: selectedDate) { newDate in
                    guard let date = newDate else { return }
                    if let entry = data.entries.first(where: { Calendar.current.isDate($0.date, inSameDayAs: date) }) {
                        selectedEntry = entry
                        showEntryDetails = true
                    }
                }
        }
        .sheet(isPresented: $showEntryDetails) {
            if let entry = selectedEntry {
                VStack(spacing: 20) {
                    Text(entry.gender)
                        .font(.title)
                        .padding(.top)
                    
                    HStack {
                        Image(entry.genderImageName)
                            .resizable()
                            .frame(width: 80, height: 80)
                        VStack(alignment: .leading) {
                            Text("Male: \(Int(entry.malePercent))%").foregroundColor(.blue)
                            Text("Female: \(Int(entry.femalePercent))%").foregroundColor(.red)
                            Text("Non-Binary: \(Int(entry.nonBinaryPercent))%").foregroundColor(.yellow)
                        }
                    }
                    
                    Text("Notes: \(entry.notes)")
                        .padding()
                    Spacer()
                }
                .padding()
            }
        }
    }
}

